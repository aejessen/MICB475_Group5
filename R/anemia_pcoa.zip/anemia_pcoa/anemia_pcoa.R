library(phyloseq)
library(ape)
library(tidyverse)
library(picante)

#### Load in RData ####
load("ap_rare.RData")
load("ap_final.RData")

#### Bray #####
bc_dm <- distance(ap_rare, method="bray")

pcoa_bc <- ordinate(ap_rare, method="PCoA", distance=bc_dm)

plot_ordination(ap_rare, pcoa_bc, color = "disease_state")

gg_pcoa <- plot_ordination(ap_rare, pcoa_bc, color = "disease_state", shape = "sex") +
  labs(pch = "Sex", col = "Disease State")
gg_pcoa

ggsave("plot_bray_pcoa.png"
       , gg_pcoa
       , height=4, width=5)

#### Jaccard #####
jac_dm <- distance(ap_rare, method="jaccard")

pcoa_jac <- ordinate(ap_rare, method="PCoA", distance=jac_dm)

plot_ordination(ap_rare, pcoa_jac, color = "disease_state")

gg_pcoa <- plot_ordination(ap_rare, pcoa_jac, color = "disease_state", shape = "sex") +
  labs(pch = "Sex", col = "Disease State")
gg_pcoa

ggsave("plot_jac_pcoa.png"
       , gg_pcoa
       , height=4, width=5)

#### weighted unifrac #####
wu_dm <- distance(ap_rare, method="wunifrac")

pcoa_wu <- ordinate(ap_rare, method="PCoA", distance=wu_dm)

plot_ordination(ap_rare, pcoa_wu, color = "disease_state")

gg_pcoa <- plot_ordination(ap_rare, pcoa_wu, color = "disease_state", shape = "sex") +
  labs(pch = "Sex", col = "Disease State")
gg_pcoa

ggsave("plot_wu_pcoa.png"
       , gg_pcoa
       , height=4, width=5)

#### unweighted unifrac #####
uni_dm <- distance(ap_rare, method="unifrac")

pcoa_uni <- ordinate(ap_rare, method="PCoA", distance=uni_dm)

plot_ordination(ap_rare, pcoa_uni, color = "disease_state")

gg_pcoa <- plot_ordination(ap_rare, pcoa_uni, color = "disease_state", shape = "sex") +
  labs(pch = "Sex", col = "Disease State")
gg_pcoa

ggsave("plot_uni_pcoa.png"
       , gg_pcoa
       , height=4, width=5)
